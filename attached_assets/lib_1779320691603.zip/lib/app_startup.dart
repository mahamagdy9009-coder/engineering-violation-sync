// ============================================================
// app_startup.dart — تشغيل الخدمات عند بدء التطبيق
// ضعه في: lib/app_startup.dart
// ============================================================
// الاستخدام في main.dart:
//
//   void main() async {
//     WidgetsFlutterBinding.ensureInitialized();
//     await AppStartup.init();
//     runApp(const MyApp());
//   }
//
// وفي dispose (ويندوز لا يدعم onExit بسهولة):
//   await AppStartup.dispose();
// ============================================================

import 'services/attachment_service.dart';

class AppStartup {
  static bool _initialized = false;

  /// يُستدعى مرة واحدة في main() قبل runApp
  static Future<void> init() async {
    if (_initialized) return;
    _initialized = true;

    try {
      // تشغيل خادم استقبال المرفقات من الموبايل (منفذ 8080)
      await AttachmentService.instance.start();
    } catch (_) {
      // الفشل هنا لا يوقف التطبيق
    }
  }

  /// يُستدعى عند إغلاق التطبيق إن أمكن
  static Future<void> dispose() async {
    await AttachmentService.instance.stop();
  }
}
